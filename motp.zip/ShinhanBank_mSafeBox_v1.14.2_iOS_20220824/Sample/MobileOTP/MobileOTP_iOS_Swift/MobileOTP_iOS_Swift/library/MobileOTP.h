//
//  MobileOTP.h
//  MobileOTP
//
//  Created by Yunju on 12/07/2019.
//  Copyright © 2019 ATON. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^_Nonnull MobileOTPCallback)(BOOL success, NSDictionary * _Nonnull result);

#pragma mark - MobileOTP
@interface MobileOTP : NSObject

/*!
 @discussion 발급된 모든 OTP 정보 조회 (Sync)
 @result NSDictionary (resultCode, resultMsg, otpAlias[alias,alias,...])
 */
+(NSDictionary *)getInfo;

/*!
 @discussion 발급된 모든 OTP 정보 조회 (Async)
 @param callback MobileOTPCallback
 */
+(void)getInfo:(MobileOTPCallback)callback;

/*!
 @discussion getVersion, getInfo 조회 (Sync)
 @result NSDictionary (resultCode, resultMsg, otpAlias[alias,alias,...], mSBVersion, libVersion)
 */
+(NSDictionary *)getAllInfo;

/*!
 @discussion getVersion, getInfo 조회  (Async)
 @param callback MobileOTPCallback
 */
+(void)getAllInfo:(MobileOTPCallback)callback;


/*!
 @discussion 발급된 OTP 존재 여부 (Sync)
 @param otpAlias otpAlias
 @result NSDictionary (resultCode, resultMsg)
 */
+(NSDictionary *)existIssuedData:(NSString *)otpAlias;

/*!
 @discussion 발급된 OTP 존재 여부 (Async)
 @param otpAlias otpAlias
 @param callback MobileOTPCallback
 */
+(void)existIssuedData:(NSString *)otpAlias callback:(MobileOTPCallback)callback;


/*!
 @discussion OTP 발급 (Sync)
 @param otpAlias otpAlias
 @param otpKey1 otpKey1
 @param otpKey2 otpKey2
 @result NSDictionary (resultCode, resultMsg)
 */
+(NSDictionary *)issue:(NSString *)otpAlias otpKey1:(NSData *)otpKey1 otpKey2:(NSData *)otpKey2;

/*!
 @discussion OTP 발급 (Async)
 @param otpAlias otpAlias
 @param otpKey1 otpKey1
 @param otpKey2 otpKey2
 @param callback MobileOTPCallback
 */
+(void)issue:(NSString *)otpAlias otpKey1:(NSData *)otpKey1 otpKey2:(NSData *)otpKey2 callback:(MobileOTPCallback)callback;


/*!
 @discussion OTP 생성 (Sync)
 @param otpAlias otpAlias
 @param siteCode siteCode
 @param otpTime otpTime
 @param hti hti
 @param isEncrypt 암호화 여부
 @result NSDictionary (resultCode, resultMsg, otp)
 */
+(NSDictionary *)generate:(NSString *)otpAlias siteCode:(NSString *)siteCode otpTime:(NSData *)otpTime hti:(NSData *)hti isEncrypt:(BOOL)isEncrypt;

/*!
 @discussion OTP 생성 (Async)
 @param otpAlias otpAlias
 @param siteCode siteCode
 @param otpTime otpTime
 @param hti hti
 @param isEncrypt 암호화 여부
 @param callback MobileOTPCallback
 */
+(void)generate:(NSString *)otpAlias siteCode:(NSString *)siteCode otpTime:(NSData *)otpTime hti:(NSData *)hti isEncrypt:(BOOL)isEncrypt callback:(MobileOTPCallback)callback;


/*!
 @discussion OTP 폐기 (Sync)
 @param otpAlias otpAlias
 @result NSDictionary (resultCode, resultMsg, publicKey)
 */
+(NSDictionary *)disuse:(NSString *)otpAlias;

/*!
 @discussion OTP 폐기 (Async)
 @param otpAlias otpAlias
 @param callback MobileOTPCallback
 */
+(void)disuse:(NSString *)otpAlias callback:(MobileOTPCallback)callback;

/*!
 @discussion OTP 폐기 (Sync)
 @param otpAlias otpAlias
 @result NSDictionary (resultCode, resultMsg, publicKey)
 */
+(NSDictionary *)dissue:(NSString *)otpAlias;

/*!
 @discussion OTP 폐기 (Async)
 @param otpAlias otpAlias
 @param callback MobileOTPCallback
 */
+(void)dissue:(NSString *)otpAlias callback:(MobileOTPCallback)callback;

/**
@brief Encrypt (Sync)
@param otpAlias otpAlias
@param otpKeyIndex otpKeyIndex
@param data 암호화할 데이터 (ByteArray)
@result NSDictionary (resultCode, resultMsg, encData)
*/
+(NSDictionary *)encrypt:(NSString *)otpAlias otpKeyIndex:(NSString *)otpKeyIndex data:(NSMutableData *)data;

/**
@brief Encrypt (Async)
@param otpAlias otpAlias
@param otpKeyIndex otpKeyIndex
@param data 암호화할 데이터 (ByteArray)
@param callback MobileSafeKeyCallback
*/
+(void)encrypt:(NSString *)otpAlias otpKeyIndex:(NSString *)otpKeyIndex data:(NSMutableData *)data callback:(MobileOTPCallback)callback;


/**
@brief Decrypt (Sync)
@param otpAlias otpAlias
@param otpKeyIndex otpKeyIndex
 @param iv iv값
@param data 복호화할 데이터 (ByteArray)
@result NSMutableDictionary (resultCode, resultMsg, decData)
*/
+(NSMutableDictionary *)decrypt:(NSString *)otpAlias otpKeyIndex:(NSString *)otpKeyIndex data:(NSMutableData *)data;

/**
@brief Decrypt (Async)
@param otpAlias otpAlias
@param otpKeyIndex otpKeyIndex
 @param iv iv값
@param data 복호화할 데이터 (ByteArray)
@param callback MobileSafeKeyCallback
*/
+(void)decrypt:(NSString *)otpAlias otpKeyIndex:(NSString *)otpKeyIndex data:(NSMutableData *)data callback:(MobileOTPCallback)callback;

/**
@brief Encrypt (Sync)
@param otpAlias otpAlias
@param otpKeyIndex otpKeyIndex
@param data 암호화할 데이터 (ByteArray)
@result NSDictionary (resultCode, resultMsg, encData)
*/
+(NSDictionary *)encrypt:(NSString *)otpAlias otpKeyIndex:(NSString *)otpKeyIndex iv:(NSData *)iv data:(NSMutableData *)data;

/**
@brief Encrypt (Async)
@param otpAlias otpAlias
@param otpKeyIndex otpKeyIndex
@param data 암호화할 데이터 (ByteArray)
@param callback MobileSafeKeyCallback
*/
+(void)encrypt:(NSString *)otpAlias otpKeyIndex:(NSString *)otpKeyIndex iv:(NSData *)iv data:(NSMutableData *)data callback:(MobileOTPCallback)callback;


/**
@brief Decrypt (Sync)
@param otpAlias otpAlias
@param otpKeyIndex otpKeyIndex
 @param iv iv값
@param data 복호화할 데이터 (ByteArray)
@result NSMutableDictionary (resultCode, resultMsg, decData)
*/
+(NSMutableDictionary *)decrypt:(NSString *)otpAlias otpKeyIndex:(NSString *)otpKeyIndex iv:(NSData *)iv data:(NSMutableData *)data;

/**
@brief Decrypt (Async)
@param otpAlias otpAlias
@param otpKeyIndex otpKeyIndex
 @param iv iv값
@param data 복호화할 데이터 (ByteArray)
@param callback MobileSafeKeyCallback
*/
+(void)decrypt:(NSString *)otpAlias otpKeyIndex:(NSString *)otpKeyIndex iv:(NSData *)iv data:(NSMutableData *)data callback:(MobileOTPCallback)callback;

@end
 
