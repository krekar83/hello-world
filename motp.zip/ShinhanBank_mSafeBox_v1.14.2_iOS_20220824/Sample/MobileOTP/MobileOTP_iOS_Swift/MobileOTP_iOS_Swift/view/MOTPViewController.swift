//
//  OTPViewController.swift
//  MobileOTP_iOS_Swift
//
//  Created by Yunju on 03/09/2019.
//  Copyright © 2019 ATON. All rights reserved.
//

import UIKit

let RESULT_CODE_SUCCESS =     "00000"
let ENCRYPTION_DATA = "123456789101112131415161718192021222324252627282930"
let IV_DEFAULT = "00000000000000000000000000000000"

class MOTPViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var authView: UIView!
    
    @IBOutlet weak var TFsiteCode: UITextField!
    @IBOutlet weak var TFotpAlias: UITextField!
    @IBOutlet weak var TFencrypt: UITextField!
    @IBOutlet weak var TFdecrypt: UITextField!
    @IBOutlet weak var TFiv: UITextField!
    
    @IBOutlet weak var segmentOTPKey: UISegmentedControl!
    
    private var bgTap: UITapGestureRecognizer?
    private var ivHexStr: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "MobileOTP"
                
        MobileAuth.initialize(UIDevice.current.identifierForVendor?.uuidString, license:"f0x8nXEZ6qjdwZ5oM/nhTu6dXecHWZIbTelA65vR03S9l0EfmVFHSXIaUwoO5G0kAAvzS74Ug+L/r4B30qHK6UFdKb8Eo3ql93t1PclEm1nMjh6V2zcgweyasb4d3A9Fc5174bq+n0o/W4Da7x02bq0yp2UFmwZfUJgKdpTiobNbso9waSubDxGTOl8sb97F4FLu2ZTE8E+8lbq7hOGCC8gUQr8oTGLZQ0e/mrnM2H0F1W5wtOvtJ+rD4Pa0OZ3SR3Fl/R5TIAlOVXlBc6uE3qyG6/VROhA2dPCPii33yT+P4xPxkETCBNvflItvVm6K13Rbuq5oD/MboefYd6Nq5g==")
        
        ivHexStr = getIv(length: 16)
        
        if let iv = ivHexStr {
            TFiv.text = ivHexStr;
        } else {
            TFiv.text = IV_DEFAULT;
        }
        
        
        bgTap = UITapGestureRecognizer.init(target: self, action: #selector(writeFinished))
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    // MARK: Common Functions
    @objc func writeFinished()
    {
        self.view.endEditing(true)
    }
    
    func showResult (title: String, message: String)
    {
        let alert = UIAlertController.init(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction.init(title: "OK", style: UIAlertAction.Style.default, handler: {
            action in
            alert.dismiss(animated: true, completion: nil)
            
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    func jsonStringPrint (dic: [AnyHashable : Any]) -> String
    {
        let jsonData: Data! = try? JSONSerialization.data(withJSONObject: dic, options: JSONSerialization.WritingOptions.prettyPrinted)
        let jsonString: String! = String(data: jsonData, encoding: String.Encoding.utf8)
        
        return jsonString ?? ""
    }
    
    func hexToBytes(_ string: String) -> [UInt8]? {
        let length = string.count
        if length & 1 != 0 {
            return nil
        }
        var bytes = [UInt8]()
        bytes.reserveCapacity(length/2)
        var index = string.startIndex
        for _ in 0..<length/2 {
            let nextIndex = string.index(index, offsetBy: 2)
            if let b = UInt8(string[index..<nextIndex], radix: 16) {
                bytes.append(b)
            } else {
                return nil
            }
            index = nextIndex
        }
        return bytes
    }
    
    func dataWithHexString(hex: String) -> Data {
        var hex = hex
        var data = Data()
        while(hex.count > 0) {
            let subIndex = hex.index(hex.startIndex, offsetBy: 2)
            let c = String(hex[..<subIndex])
            hex = String(hex[subIndex...])
            var ch: UInt32 = 0
            Scanner(string: c).scanHexInt32(&ch)
            var char = UInt8(ch)
            data.append(&char, count: 1)
        }
        return data
    }
    
    func dataToHexString(data: Data) -> String {
        let size = data.count
        let randomBytes = data.bytes
        var hexStr = String(repeating: "\0", count: 0)
        
        for index in 0..<size {
            hexStr = hexStr + String(format: "%02x", randomBytes[index])
        }
        
        return hexStr
        
    }
    
    func makeRandData(size: Int) -> Data? {
        var randomBytes = [UInt8](repeating: 0, count: size)
        let result = Int(SecRandomCopyBytes(kSecRandomDefault, size, &randomBytes))
        if result == 0 {
            return Data(bytes: &randomBytes, count: size)
        }
        return Data()
    }
    
    func getIv(length: Int) -> String? {
        if let iv : Data = makeRandData(size: length) {
            return dataToHexString(data: iv)
        }
        return ""
        
    }
    
    // MARK: UITextFieldDelegate
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == self.TFsiteCode {
            let sCode: String! = textField.text
            if sCode.count > 0 {
                let siteCode: String! = sCode.substring(with: (sCode.count - 3)..<6)
                self.TFotpAlias.text = String(format: "512%@000000001", siteCode)
            }
        }
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // MARK: Actions
    @IBAction func actionBtnSetDeviceId(_ sender: Any) {
        let title: String! = "Set Device ID"
        var msg: String! = ""
        
        // Sync
        let resDic: Dictionary! = MobileAuth.setDeviceId(UIDevice.current.identifierForVendor?.uuidString)
        
        if resDic["resultCode"] as! String? == RESULT_CODE_SUCCESS {
            msg = self.jsonStringPrint(dic: resDic)
            self.showResult(title: title, message: msg)
        } else {
            msg = self.jsonStringPrint(dic: resDic)
            self.showResult(title: "Set Device ID 실패", message: msg)
        }
    }
    
    @IBAction func actionBtnVersion(_ sender: Any) {
        let title: String! = "버전 조회"
        var msg: String! = ""
        
        // Sync
        let resDic: Dictionary! = MobileAuth.getVersion()
        
        if resDic["resultCode"] as! String? == RESULT_CODE_SUCCESS {
            msg = self.jsonStringPrint(dic: resDic)
            self.showResult(title: title, message: msg)
        } else {
            msg = self.jsonStringPrint(dic: resDic)
            self.showResult(title: "버전 조회 실패", message: msg)
        }
        
        // Async
//        MobileAuth.getVersion({ (success: Bool, result: Dictionary) in
//            if success == true {
//                msg = self.jsonStringPrint(dic: result)
//                self.showResult(title: title, message: msg)
//            } else {
//                msg = self.jsonStringPrint(dic: result)
//                self.showResult(title: "버전 조회 실패", message: msg)
//            }
//        })
    }
    
    @IBAction func actionBtnInfo(_ sender: Any) {
        let title: String! = "정보 조회"
        var msg: String! = ""
        
        // Sync
        let resDic: Dictionary! = MobileOTP.getInfo()
        
        if resDic["resultCode"] as! String? == RESULT_CODE_SUCCESS {
            print("MobileOTP getInfo success")
            let otpAlias = resDic["otpAlias"] as! NSArray?
            if let otpAlias = otpAlias {
                print("getInfo otpAlias \(otpAlias)")
            }
            
            msg = self.jsonStringPrint(dic: resDic)
            self.showResult(title: title, message: msg)
        } else {
            msg = self.jsonStringPrint(dic: resDic)
            self.showResult(title: "정보 조회 실패", message: msg)
        }
        
        
        // Async
//        MobileOTP.getInfo({ (success: Bool, result: Dictionary) in
//            if success == true {
//                print("MobileOTP getInfo success")
//                let otpAlias = resDic["resultCode"] as! String?
//                if let otpAlias = otpAlias {
//                    print("getInfo otpAlias \(otpAlias)")
//                }
//                msg = self.jsonStringPrint(dic: result)
//                self.showResult(title: title, message: msg)
//            } else {
//                msg = self.jsonStringPrint(dic: result)
//                self.showResult(title: "정보 조회 실패", message: msg)
//            }
//        })
    }
    
    @IBAction func actionBtnIssue(_ sender: Any) {
        let title: String! = "OTP 발급"
        var msg: String! = ""
        
        if self.TFotpAlias.text?.count != 0 {
            let key1: [UInt8]! = self.hexToBytes("000000000000000000000000000000002F5B8B5ED829A8CEF1599FFF8D87C17B")
            let key2: [UInt8]! = self.hexToBytes("000000000000000000000000000000001798277C4DDB8D2A733F2E7AB65CDF63")
            let otpKey1: NSData! = NSData(bytes: key1, length: key1.count)
            let otpKey2: NSData! = NSData(bytes: key2, length: key2.count)
            
            // Sync
            let resDic: Dictionary! = MobileOTP.issue(self.TFotpAlias.text, otpKey1: otpKey1 as Data?, otpKey2: otpKey2 as Data?)

            if resDic["resultCode"] as! String? == RESULT_CODE_SUCCESS {
                print("MobileOTP issue success")
                            
                msg = self.jsonStringPrint(dic: resDic)
                self.showResult(title: title, message: msg)
            } else {
                msg = self.jsonStringPrint(dic: resDic)
                self.showResult(title: "OTP 발급 실패", message: msg)
            }
            
            // Async
//            MobileOTP.issue(self.TFotpAlias.text, otpKey1: otpKey1 as Data?, otpKey2: otpKey2 as Data?, callback:{ (success: Bool, result: Dictionary) in
//                if success == true {
//                    msg = self.jsonStringPrint(dic: result)
//                    self.showResult(title: title, message: msg)
//                } else {
//                    msg = self.jsonStringPrint(dic: result)
//                    self.showResult(title: "OTP 발급 실패", message: msg)
//                }
//            })
            
        } else {
            self.showResult(title: "OTP 발급 실패", message: "otpAlias를 입력해주세요.")
        }
    }
    
    @IBAction func actionBtnGenerate(_ sender: Any) {
        let title: String! = "OTP 생성"
        var msg: String! = ""
        
        if self.TFotpAlias.text?.count != 0 {
            let timeData: [UInt8]! = self.hexToBytes("FE45EC819CEE7C07967A656CC6A16B2C")
            let htiData: [UInt8]! = self.hexToBytes("2CF24DBA5FB0A30E26E83B2AC5B9E29E1B161E5C1FA7425E73043362938B9824")
            let otpTime: NSData! = NSData(bytes: timeData, length: timeData.count)
            let otpHti: NSData! = NSData(bytes: htiData, length: htiData.count)
            
            // Sync
            let resDic: Dictionary! = MobileOTP.generate(self.TFotpAlias.text, siteCode: self.TFsiteCode.text, otpTime: otpTime as Data?, hti: otpHti as Data?, isEncrypt: false)
            
            if resDic["resultCode"] as! String? == RESULT_CODE_SUCCESS {
                print("MobileOTP generate success")
                let otp = resDic["otp"] as! String?
                if let otp = otp {
                    print("generate otp \(otp)")
                }
                
                msg = self.jsonStringPrint(dic: resDic)
                self.showResult(title: title, message: msg)
            } else {
                msg = self.jsonStringPrint(dic: resDic)
                self.showResult(title: "OTP 생성 실패", message: msg)
            }
            
            // Async
    //        MobileOTP.generate(self.TFotpAlias.text, siteCode: self.TFsiteCode.text, otpTime: otpTime as Data?, hti: otpHti as Data?, isEncrypt: false, callback: { (success: Bool, result: Dictionary) in
    //            if success == true {
    //                msg = self.jsonStringPrint(dic: result)
    //                self.showResult(title: title, message: msg)
    //            } else {
    //                msg = self.jsonStringPrint(dic: result)
    //                self.showResult(title: "OTP 생성 실패", message: msg)
    //            }
    //        })
        } else {
            self.showResult(title: "OTP 생성 실패", message: "otpAlias를 입력해주세요.")
        }
    }
    
    @IBAction func actionBtnDisuse(_ sender: Any) {
        let title: String! = "OTP 폐기"
        var msg: String! = ""
        
        if self.TFotpAlias.text?.count != 0 {
            // Sync
            let resDic: Dictionary! = MobileOTP.disuse(self.TFotpAlias.text)
            
            if resDic["resultCode"] as! String? == RESULT_CODE_SUCCESS {
                print("MobileOTP disuse success")
                msg = self.jsonStringPrint(dic: resDic)
                self.showResult(title: title, message: msg)
            } else {
                msg = self.jsonStringPrint(dic: resDic)
                self.showResult(title: "OTP 폐기 실패", message: msg)
            }
            
            // Async
    //        MobileOTP.disuse(self.TFotpAlias.text, callback: { (success: Bool, result: Dictionary) in
    //            if success == true {
    //                msg = self.jsonStringPrint(dic: result)
    //                self.showResult(title: title, message: msg)
    //            } else {
    //                msg = self.jsonStringPrint(dic: result)
    //                self.showResult(title: "OTP 폐기 실패", message: msg)
    //            }
    //        })
        } else {
            self.showResult(title: "OTP 폐기 실패", message: "otpAlias를 입력해주세요.")
        }
    }
    
    // MARK: Encrypt/Decrypt
    @IBAction func actionBtnEncrypt(_ sender: Any) {
        let title: String! = "암호화"
        var msg: String! = ""
        
        self.TFencrypt.text = ""
        self.TFdecrypt.text = ""
        
        let strData: String! = ENCRYPTION_DATA
        let segmentOTPKey = String(self.segmentOTPKey.selectedSegmentIndex)
        let data: Data! = strData.data(using: .utf8)
        let muData: NSMutableData! = NSMutableData.init(data: data)
        
        // Sync
        var resDic = MobileOTP.encrypt(self.TFotpAlias.text, otpKeyIndex: segmentOTPKey, data: muData) as! Dictionary<String, Any>

        if resDic["resultCode"] as! String == RESULT_CODE_SUCCESS {
            print("MobileOTP encrypt success")
            let data = resDic["encData"] as! Data?
            var encData = ""
            if let data = data {
                encData = data.hexEncodedString()
            }
            print("encrypt encData \(encData)")
            
            resDic["encData"] = encData
            self.TFencrypt.text = encData
            
            msg = self.jsonStringPrint(dic: resDic)
            self.showResult(title: title, message: msg)

        } else {
            msg = self.jsonStringPrint(dic: resDic)
            self.showResult(title: "암호화 실패", message: msg)
        }
        
        // Async
//        MobileOTP.encrypt(self.TFotpAlias.text, otpKeyIndex: segmentOTPKey, data: muData) { (success: Bool, result: Dictionary) in
//            if success == true {
//                var resDic: Dictionary = result
//
//                let data: Data! = resDic["encData"] as? Data
//                let strData: String! = data.hexEncodedString()
//                resDic["encData"] = strData
//
//                self.TFencrypt.text = strData
//
//                msg = self.jsonStringPrint(dic: resDic)
//                self.showResult(title: title, message: msg)
//
//            } else {
//                msg = self.jsonStringPrint(dic: result)
//                self.showResult(title: "암호화 실패", message: msg)
//            }
//        }
    }
    
    @IBAction func actionBtnDecrypt(_ sender: Any) {
        let title: String! = "복호화"
        var msg: String! = ""
        
        let strData: String! = self.TFencrypt.text
        let segmentOTPKey = String(self.segmentOTPKey.selectedSegmentIndex)
        let data: Data! = self.dataWithHexString(hex: strData)
        let muData: NSMutableData! = NSMutableData.init(data: data)
        
        // Sync
        var resDic = MobileOTP.decrypt(self.TFotpAlias.text, otpKeyIndex: segmentOTPKey, data: muData) as! Dictionary<String, Any>

        if resDic["resultCode"] as! String == RESULT_CODE_SUCCESS {
            print("MobileOTP decrypt success")
            
            let data = resDic["decData"] as! Data?
            var decData = ""
            if let data = data {
                decData = String(data: data, encoding: .utf8)!
            }
            print("decrypt decData \(decData)")
            
            resDic["decData"] = decData
            
            self.TFencrypt.text = ""
            self.TFdecrypt.text = decData

            msg = self.jsonStringPrint(dic: resDic)
            self.showResult(title: title, message: msg)

        } else {
            msg = self.jsonStringPrint(dic: resDic)
            self.showResult(title: "복호화 실패", message: msg)
        }
        
        // Async
//        MobileOTP.decrypt(self.TFotpAlias.text, otpKeyIndex: segmentOTPKey, data: muData) { (success: Bool, result: Dictionary) in
//            if success == true {
//                var resDic: Dictionary = result
//
//                let data: Data! = resDic["decData"] as? Data
//                let strData: String! = String(data: data, encoding: .utf8)
//                resDic["decData"] = strData
//
//                self.TFencrypt.text = ""
//                self.TFdecrypt.text = strData
//
//                msg = self.jsonStringPrint(dic: resDic)
//                self.showResult(title: title, message: msg)
//
//            } else {
//                msg = self.jsonStringPrint(dic: result)
//                self.showResult(title: "복호화 실패", message: msg)
//            }
//        }
    }
    
    
    // MARK: Encrypt/Decrypt AES with iv
    @IBAction func actionBtnEncryptAES(_ sender: Any) {
        let title: String! = "암호화(AES)"
        var msg: String! = ""
        
        self.TFencrypt.text = ""
        self.TFdecrypt.text = ""
        
        let strData: String! = ENCRYPTION_DATA
        let segmentOTPKey = String(self.segmentOTPKey.selectedSegmentIndex)
        let data: Data! = strData.data(using: .utf8)
        let muData: NSMutableData! = NSMutableData.init(data: data)
        let ivData: Data!
        
        if let iv = ivHexStr {
            ivData = self.dataWithHexString(hex: iv)
        } else {
            ivData = self.dataWithHexString(hex: IV_DEFAULT);
        }
        
        
        // Sync
        var resDic = MobileOTP.encrypt(self.TFotpAlias.text, otpKeyIndex: segmentOTPKey, iv: ivData,  data: muData) as! Dictionary<String, Any>

        if resDic["resultCode"] as! String == RESULT_CODE_SUCCESS {
            print("MobileOTP encrypt success")
            let data = resDic["encData"] as! Data?
            var encData = ""
            if let data = data {
                encData = data.hexEncodedString()
            }
            print("encrypt encData \(encData)")
            
            resDic["encData"] = encData
            self.TFencrypt.text = encData
            
            msg = self.jsonStringPrint(dic: resDic)
            self.showResult(title: title, message: msg)

        } else {
            msg = self.jsonStringPrint(dic: resDic)
            self.showResult(title: "암호화 실패", message: msg)
        }
        
        // Async
//        MobileOTP.encrypt(self.TFotpAlias.text, otpKeyIndex: segmentOTPKey, iv: ivData, data: muData) { (success: Bool, result: Dictionary) in
//            if success == true {
//                var resDic: Dictionary = result
//
//                let data: Data! = resDic["encData"] as? Data
//                let strData: String! = data.hexEncodedString()
//                resDic["encData"] = strData
//
//                self.TFencrypt.text = strData
//
//                msg = self.jsonStringPrint(dic: resDic)
//                self.showResult(title: title, message: msg)
//
//            } else {
//                msg = self.jsonStringPrint(dic: result)
//                self.showResult(title: "암호화 실패", message: msg)
//            }
//        }
    }
    
    @IBAction func actionBtnDecryptAES(_ sender: Any) {
        let title: String! = "복호화(AES)"
        var msg: String! = ""
        
        let strData: String! = self.TFencrypt.text
        let segmentOTPKey = String(self.segmentOTPKey.selectedSegmentIndex)
        let data: Data! = self.dataWithHexString(hex: strData)
        let muData: NSMutableData! = NSMutableData.init(data: data)
        let ivData: Data!
        
        if let iv = ivHexStr {
            ivData = self.dataWithHexString(hex: iv)
        } else {
            ivData = self.dataWithHexString(hex: IV_DEFAULT);
        }
        
        
        // Sync
        var resDic = MobileOTP.decrypt(self.TFotpAlias.text, otpKeyIndex: segmentOTPKey, iv: ivData, data: muData) as! Dictionary<String, Any>

        if resDic["resultCode"] as! String == RESULT_CODE_SUCCESS {
            print("MobileOTP decrypt success")
            
            let data = resDic["decData"] as! Data?
            var decData = ""
            if let data = data {
                decData = String(data: data, encoding: .utf8)!
            }
            print("decrypt decData \(decData)")
            
            resDic["decData"] = decData
            
            self.TFencrypt.text = ""
            self.TFdecrypt.text = decData

            msg = self.jsonStringPrint(dic: resDic)
            self.showResult(title: title, message: msg)

        } else {
            msg = self.jsonStringPrint(dic: resDic)
            self.showResult(title: "복호화 실패", message: msg)
        }
        
        // Async
//        MobileOTP.decrypt(self.TFotpAlias.text, otpKeyIndex: segmentOTPKey, iv: ivData, data: muData) { (success: Bool, result: Dictionary) in
//            if success == true {
//                var resDic: Dictionary = result
//
//                let data: Data! = resDic["decData"] as? Data
//                let strData: String! = String(data: data, encoding: .utf8)
//                resDic["decData"] = strData
//
//                self.TFencrypt.text = ""
//                self.TFdecrypt.text = strData
//
//                msg = self.jsonStringPrint(dic: resDic)
//                self.showResult(title: title, message: msg)
//
//            } else {
//                msg = self.jsonStringPrint(dic: result)
//                self.showResult(title: "복호화 실패", message: msg)
//            }
//        }
    }
    
    // MARK: Keyboard Notification
    @objc func keyboardWillShow(notification: NSNotification) {
        view.addGestureRecognizer(bgTap!)
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        view.removeGestureRecognizer(bgTap!)
    }
    
}
