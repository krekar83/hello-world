//
//  AuthViewController.swift
//  MobileOTP_iOS_Swift
//
//  Created by 강은경 on 2021/03/18.
//  Copyright © 2021 ATON. All rights reserved.
//

import UIKit

class MAuthViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationItem.title = "MobileAuth"
    }
    
    // MARK: Common
    func showResult (title: String, message: String) {
        let alert = UIAlertController.init(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction.init(title: "OK", style: UIAlertAction.Style.default, handler: {
            (action) in
            alert.dismiss(animated: true, completion: nil)
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    func jsonStringPrint (dic: [AnyHashable: Any]) -> String {
        let jsonData: Data! = try? JSONSerialization.data(withJSONObject: dic, options: JSONSerialization.WritingOptions.prettyPrinted)
        let jsonString: String! = String(data: jsonData, encoding: String.Encoding.utf8)
        
        return jsonString ?? ""
    }
    
    
    // MARK: Action
    @IBAction func actionBtnInitialize(_ sender: Any) {
        let title = "Initialize"
        var msg = ""
        
        // sync
        let resDic = MobileAuth.initialize(UIDevice.current.identifierForVendor?.uuidString, license: "D2fPsaw6Xv55uFirWobdwVOGlOAgcgEMK1aEnvAIZKDQfoewrFC/n+plEVUFOQGHkDVIUvqd4FVtwnUgPHPMf17uCeF8bbY0CjeWKrYnNvFvgwhcP+/ncJ/GOj0rOGpVGhv/YaJADxAoKlIRaZo+Rx4Lks098QN+d9wPWTswy3tkLU0qVoJYg26u6raOtDuh6PN9KmfgDvV+xVdlaKWMAEgBetA4i5Klxbcr3+T8mu7a4q3wdhxdlSISLJENl6xIu02cnBNBw28s6KQBXB2ejmpb0XkbA7S9VxpioOzQAZz0MK1vPhUFfDNnHc7AdwQpj7y0PX2kg8nX+wKq2a4nzA==") as! Dictionary<String, Any>
        msg = self.jsonStringPrint(dic: resDic)
        self.showResult(title: title, message: msg)
     
        
        // async
//        MobileAuth.initialize(UIDevice.current.identifierForVendor?.uuidString, license: "D2fPsaw6Xv55uFirWobdwVOGlOAgcgEMK1aEnvAIZKDQfoewrFC/n+plEVUFOQGHkDVIUvqd4FVtwnUgPHPMf17uCeF8bbY0CjeWKrYnNvFvgwhcP+/ncJ/GOj0rOGpVGhv/YaJADxAoKlIRaZo+Rx4Lks098QN+d9wPWTswy3tkLU0qVoJYg26u6raOtDuh6PN9KmfgDvV+xVdlaKWMAEgBetA4i5Klxbcr3+T8mu7a4q3wdhxdlSISLJENl6xIu02cnBNBw28s6KQBXB2ejmpb0XkbA7S9VxpioOzQAZz0MK1vPhUFfDNnHc7AdwQpj7y0PX2kg8nX+wKq2a4nzA==") { (success: Bool, result: Dictionary) in
//            msg = self.jsonStringPrint(dic: result)
//            self.showResult(title: title, message: msg)
//        }
            
    }
        
    @IBAction func actionBtnSetDeviceId(_ sender: Any) {
        let title = "Set Device ID"
        var msg = ""
        
        // sync
        let resDic = MobileAuth.setDeviceId(UIDevice.current.identifierForVendor?.uuidString) as! Dictionary<String, Any>
        if resDic["resultCode"] as! String? == RESULT_CODE_SUCCESS {
            print("MobileAuth SetdeviceId success")
        }
        msg = self.jsonStringPrint(dic: resDic)
        self.showResult(title: title, message: msg)
                
        
        // async
//        MobileAuth.setDeviceId(UIDevice.current.identifierForVendor?.uuidString) { (success: Bool, result: Dictionary) in
//            msg = self.jsonStringPrint(dic: result)
//            self.showResult(title: title, message: msg)
//        }
    }
    
    @IBAction func actionBtnVersion(_ sender: Any) {
        let title = "Get Version"
        var msg = ""
        
        // sync
        let resDic = MobileAuth.getVersion() as! Dictionary<String, Any>
        if resDic["resultCode"] as! String? == RESULT_CODE_SUCCESS {
            print("MobileAuth getVersion success")
            
            let mSBVersion = resDic["mSBVersion"] as! String?
            let libVersion = resDic["libVersion"] as! String?
            if let mSBVersion = mSBVersion {
                print("MobileAuth mSBVersion \(mSBVersion)")
            }
            if let libVersion = libVersion {
                print("MobileAuth libVersion \(libVersion)")
            }
        }
        msg = self.jsonStringPrint(dic: resDic)
        self.showResult(title: title, message: msg)
        
        // async
//        MobileAuth.getVersion({ (success: Bool, result: Dictionary) in
//            msg = self.jsonStringPrint(dic: result)
//            self.showResult(title: title, message: msg)
//        })
    }
    
    @IBAction func actionBtnResetData(_ sender: Any) {
        let title = "Reset Data"
        var msg = ""
        
        // sync
        let resDic = MobileAuth.resetData() as! Dictionary<String, Any>
        if resDic["resultCode"] as! String? == RESULT_CODE_SUCCESS {
            print("MobileAuth resetData success")
        }
        msg = self.jsonStringPrint(dic: resDic)
        self.showResult(title: title, message: msg)
        
        // async
//        MobileAuth.resetData { (success: Bool, result: Dictionary) in
//            msg = self.jsonStringPrint(dic: resDic)
//            self.showResult(title: title, message: msg)
//
//        }
        
        // resetData이후에 initialize API를 수행해야 SDK 사용가능
        MobileAuth.initialize(UIDevice.current.identifierForVendor?.uuidString, license: "D2fPsaw6Xv55uFirWobdwVOGlOAgcgEMK1aEnvAIZKDQfoewrFC/n+plEVUFOQGHkDVIUvqd4FVtwnUgPHPMf17uCeF8bbY0CjeWKrYnNvFvgwhcP+/ncJ/GOj0rOGpVGhv/YaJADxAoKlIRaZo+Rx4Lks098QN+d9wPWTswy3tkLU0qVoJYg26u6raOtDuh6PN9KmfgDvV+xVdlaKWMAEgBetA4i5Klxbcr3+T8mu7a4q3wdhxdlSISLJENl6xIu02cnBNBw28s6KQBXB2ejmpb0XkbA7S9VxpioOzQAZz0MK1vPhUFfDNnHc7AdwQpj7y0PX2kg8nX+wKq2a4nzA==") { (success: Bool, result: Dictionary) in
            msg = self.jsonStringPrint(dic: result)
            self.showResult(title: title, message: msg)
        }
    }
    
    @IBAction func actionBtnDumpData(_ sender: Any) {
        let title = "Dump Data"
        var msg = ""
        
        // sync
        let resDic = MobileAuth.dumpData() as! Dictionary<String, Any>
        if resDic["resultCode"] as! String? == RESULT_CODE_SUCCESS {
            print("MobileAuth dumpData success")
            if let dumpData = resDic["dumpData"] {
                print("dumpData \(dumpData)")
            }
            
        }
        msg = self.jsonStringPrint(dic: resDic)
        self.showResult(title: title, message: msg)
        
        // async
//        MobileAuth.dumpData({ (success: Bool, result: Dictionary) in
//            msg = self.jsonStringPrint(dic: result)
//            self.showResult(title: title, message: msg)
//        })
        
        // resetData이후에 initialize API를 수행해야 SDK 사용가능
        MobileAuth.initialize(UIDevice.current.identifierForVendor?.uuidString, license: "D2fPsaw6Xv55uFirWobdwVOGlOAgcgEMK1aEnvAIZKDQfoewrFC/n+plEVUFOQGHkDVIUvqd4FVtwnUgPHPMf17uCeF8bbY0CjeWKrYnNvFvgwhcP+/ncJ/GOj0rOGpVGhv/YaJADxAoKlIRaZo+Rx4Lks098QN+d9wPWTswy3tkLU0qVoJYg26u6raOtDuh6PN9KmfgDvV+xVdlaKWMAEgBetA4i5Klxbcr3+T8mu7a4q3wdhxdlSISLJENl6xIu02cnBNBw28s6KQBXB2ejmpb0XkbA7S9VxpioOzQAZz0MK1vPhUFfDNnHc7AdwQpj7y0PX2kg8nX+wKq2a4nzA==") { (success: Bool, result: Dictionary) in
            msg = self.jsonStringPrint(dic: result)
            self.showResult(title: title, message: msg)
        }
    }
}
