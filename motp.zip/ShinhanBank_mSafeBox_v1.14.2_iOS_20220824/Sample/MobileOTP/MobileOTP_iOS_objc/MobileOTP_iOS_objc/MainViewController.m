//
//  MainViewController.m
//  MobileOTP_iOS_objc
//
//  Created by 강은경 on 2021/03/17.
//

#import "MainViewController.h"

#import "MAuthViewController.h"
#import "MOTPViewController.h"

#import "MobileAuth.h"

@interface MainViewController ()

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"MobileOTP Sample";
    
    
    //Device ID Setting!! -> Required
    NSDictionary *resDic = [MobileAuth initialize:[[UIDevice currentDevice] identifierForVendor].UUIDString license:@"f0x8nXEZ6qjdwZ5oM/nhTu6dXecHWZIbTelA65vR03S9l0EfmVFHSXIaUwoO5G0kAAvzS74Ug+L/r4B30qHK6UFdKb8Eo3ql93t1PclEm1nMjh6V2zcgweyasb4d3A9Fc5174bq+n0o/W4Da7x02bq0yp2UFmwZfUJgKdpTiobNbso9waSubDxGTOl8sb97F4FLu2ZTE8E+8lbq7hOGCC8gUQr8oTGLZQ0e/mrnM2H0F1W5wtOvtJ+rD4Pa0OZ3SR3Fl/R5TIAlOVXlBc6uE3qyG6/VROhA2dPCPii33yT+P4xPxkETCBNvflItvVm6K13Rbuq5oD/MboefYd6Nq5g=="];
    if ([[resDic objectForKey:@"resultCode"] isEqualToString:@"00000"]) {
        NSLog(@"MobileAuth:: initialize - success");
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)actionBtnAuth:(id)sender {
    MAuthViewController *authVC = [[MAuthViewController alloc] init];
    [self.navigationController pushViewController:authVC animated:YES];
}


- (IBAction)actionBtnOTP:(id)sender {
    MOTPViewController *otpVC = [[MOTPViewController alloc] init];
    [self.navigationController pushViewController:otpVC animated:YES];
}
@end
