//
//  MobileAuth.h
//  MobileAuth
//
//  Created by Yunju on 2020/11/26.
//  Copyright © 2020 ATON. All rights reserved.
//

#import <Foundation/Foundation.h>

#define MOBILEAUTH_LIBRARY_VERSION  @"1.14.2"

typedef void (^_Nonnull MobileAuthCallback)(BOOL success, NSDictionary * _Nonnull result);

#pragma mark - MobileAuth
@interface MobileAuth : NSObject

/*!
 @discussion 라이브러리 초기화 (Sync)
 @param deviceId deviceId
 @param license License
 @result NSDictionary (resultCode, resultMsg)
 */
+(NSDictionary *)initialize:(NSString *)deviceId license:(NSString *)license;

/*!
 @discussion 라이브러리 초기화 (Async)
 @param deviceId deviceId
 @param license License
 @param callback MobileAuthCallback
 */
+(void)initialize:(NSString *)deviceId license:(NSString *)license callback:(MobileAuthCallback)callback;


/*!
 @discussion deviceId 변경 (Sync)
 @param deviceId deviceId
 @result NSDictionary (resultCode, resultMsg)
 */
+(NSDictionary *)setDeviceId:(NSString *)deviceId;

/*!
 @discussion deviceId 변경 (Async)
 @param deviceId deviceId
 @param callback MobileAuthCallback
 */
+(void)setDeviceId:(NSString *)deviceId callback:(MobileAuthCallback)callback;


/*!
 @discussion library 버전 조회 (Sync)
 @result NSDictionary (resultCode, resultMsg, mSBVersion, libVersion)
 */
+(NSDictionary *)getVersion;

/*!
 @discussion library 버전 조회 (ASync)
 @param callback MobileAuthCallback
 */
+(void)getVersion:(MobileAuthCallback)callback;


/*!
 @discussion resetData (Sync)
 @result NSDictionary (resultCode, resultMsg)
 */
+(NSDictionary *)resetData;

/*!
 @discussion resetData (Async)
 @param callback MobileAuthCallback
 */
+(void)resetData:(MobileAuthCallback)callback;


/*!
 @discussion dump Data (Sync)
 @result NSDictionary (resultCode, resultMsg, dumpData)
 */
+(NSDictionary *)dumpData;

/*!
 @discussion dump Data (Async)
 @param callback MobileAuthCallback
 */
+(void)dumpData:(MobileAuthCallback)callback;


@end
