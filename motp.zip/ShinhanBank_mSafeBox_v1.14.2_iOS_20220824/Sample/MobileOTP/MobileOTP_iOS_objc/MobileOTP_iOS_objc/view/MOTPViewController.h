//
//  MOTPViewController.h
//  MobileOTP_iOS_objc
//
//  Created by Yunju on 2020/11/20.
//

#import <UIKit/UIKit.h>


@interface MOTPViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *TFsiteCode;
@property (weak, nonatomic) IBOutlet UITextField *TFotpAlias;
@property (weak, nonatomic) IBOutlet UITextField *TFiv;
@property (weak, nonatomic) IBOutlet UITextField *TFencrypt;
@property (weak, nonatomic) IBOutlet UITextField *TFdecrypt;


@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentOTPKey;

- (IBAction)actionBtnSetDeviceId:(id)sender;
- (IBAction)actionBtnVersion:(id)sender;
- (IBAction)actionBtnInfo:(id)sender;
- (IBAction)actionBtnIssue:(id)sender;
- (IBAction)actionBtnGenerate:(id)sender;
- (IBAction)actionBtnDisuse:(id)sender;

@end

