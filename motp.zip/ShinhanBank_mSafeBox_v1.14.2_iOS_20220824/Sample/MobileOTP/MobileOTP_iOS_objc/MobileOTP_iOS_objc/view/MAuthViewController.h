//
//  MAuthViewController.h
//  SolutionSample_objc
//
//  Created by Yunju on 2020/11/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MAuthViewController : UIViewController

- (IBAction)actionBtnInitialize:(id)sender;
- (IBAction)actionBtnSetDeviceId:(id)sender;
- (IBAction)actionBtnVersion:(id)sender;
- (IBAction)actionBtnResetData:(id)sender;
- (IBAction)actionBtnDumpData:(id)sender;

@end

NS_ASSUME_NONNULL_END
