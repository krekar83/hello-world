//
//  MOTPViewController.m
//  MobileOTP_iOS_objc
//
//  Created by Yunju on 2020/11/20.
//

#import "MOTPViewController.h"
#import "MobileOTP.h"
#import "MobileAuth.h"

#define RESULT_CODE_SUCCESS  @"00000"
#define ENCRYPTION_DATA     @"123456789101112131415161718192021222324252627282930"

@interface MOTPViewController () <UITextFieldDelegate> {
    UITapGestureRecognizer *bgTap;
    NSString* ivHexStr;
    
}

@end

@implementation MOTPViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.navigationItem.title = @"MobileOTP";
    
    //Device ID Setting!! -> Required
    [MobileAuth initialize:[[UIDevice currentDevice] identifierForVendor].UUIDString license:@"f0x8nXEZ6qjdwZ5oM/nhTu6dXecHWZIbTelA65vR03S9l0EfmVFHSXIaUwoO5G0kAAvzS74Ug+L/r4B30qHK6UFdKb8Eo3ql93t1PclEm1nMjh6V2zcgweyasb4d3A9Fc5174bq+n0o/W4Da7x02bq0yp2UFmwZfUJgKdpTiobNbso9waSubDxGTOl8sb97F4FLu2ZTE8E+8lbq7hOGCC8gUQr8oTGLZQ0e/mrnM2H0F1W5wtOvtJ+rD4Pa0OZ3SR3Fl/R5TIAlOVXlBc6uE3qyG6/VROhA2dPCPii33yT+P4xPxkETCBNvflItvVm6K13Rbuq5oD/MboefYd6Nq5g=="];
    
    ivHexStr = [self getIv:16];
    self.TFiv.text = ivHexStr;
    
    bgTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(writeFinished)];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleKeyboardWillShowNote:) name:UIKeyboardWillShowNotification object:self.view.window];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleKeyboardWillHideNote:) name:UIKeyboardWillHideNotification object:self.view.window];
}

#pragma mark - Commons
- (void) writeFinished {
    [self.view endEditing:YES];
}

- (void)showResult:(NSString *)title message:(NSString *)message
{
    UIAlertController * alert=   [UIAlertController
                                  alertControllerWithTitle:title
                                  message:message
                                  preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* ok = [UIAlertAction
                         actionWithTitle:@"OK"
                         style:UIAlertActionStyleDefault
                         handler:^(UIAlertAction * action)
                         {
                             [alert dismissViewControllerAnimated:YES completion:nil];
                         }];
    
    [alert addAction:ok];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (NSString*)jsonStringPrint : (NSDictionary *)dic
{
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:nil];
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}

- (NSData *) hexToByteArray:(NSString *)hex
{
    if (hex.length == 0) { return nil; }
    
    static const unsigned char HexDecodeChars[] =
    {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 1, //49
        2, 3, 4, 5, 6, 7, 8, 9, 0, 0, //59
        0, 0, 0, 0, 0, 10, 11, 12, 13, 14,
        15, 0, 0, 0, 0, 0, 0, 0, 0, 0, //79
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 10, 11, 12, //99
        13, 14, 15
    };
    
    // convert data(NSString) to CString
    const char *source = [hex cStringUsingEncoding:NSUTF8StringEncoding];
    // malloc buffer
    unsigned char *buffer;
    NSUInteger length = strlen(source) / 2;
    buffer = malloc(length);
    for (NSUInteger index = 0; index < length; index++) {
        buffer[index] = (unsigned char)(HexDecodeChars[(size_t)source[index * 2]] << 4) + (HexDecodeChars[(size_t)source[index * 2 + 1]]);
    }
    
    // init result NSData
    NSData *result = [NSData dataWithBytes:buffer length:length];
    free(buffer);
    source = nil;
    
    return result;
}

- (NSString*)dataToHexString:(NSData*)data {
    size_t size = [data length];
    const uint8_t * const randomBytes = [data bytes];
    NSMutableString *hexStr;
    hexStr = [[NSMutableString alloc] initWithCapacity:size];
    for(NSInteger accessKeyIndex = 0; accessKeyIndex < data.length; accessKeyIndex++)
    {
        [hexStr appendFormat: @"%02x", randomBytes[accessKeyIndex]];
    }
    return hexStr;
}

- (NSData*)dataFromHexString:(NSString *)string
{
    string = [string lowercaseString];
    NSMutableData *data= [NSMutableData new];
    unsigned char whole_byte;
    char byte_chars[3] = {'\0','\0','\0'};
    int i = 0;
    int length = (int)string.length;
    while (i < length-1) {
        char c = [string characterAtIndex:i++];
        if (c < '0' || (c > '9' && c < 'a') || c > 'f')
            continue;
        byte_chars[0] = c;
        byte_chars[1] = [string characterAtIndex:i++];
        whole_byte = strtol(byte_chars, NULL, 16);
        [data appendBytes:&whole_byte length:1];
    }
    return data;
}

- (NSData *)makeRandData:(int)size {
//    int size = 32;
    if(size == 0) {
        return nil;
    }
    uint8_t randomBytes[size];
    //NSMutableString *ivStr;
    int result = SecRandomCopyBytes(kSecRandomDefault, size, randomBytes);
    if(result == 0) {
        return [[NSData alloc] initWithBytes:randomBytes length:size];
    }
    return nil;
}

- (NSString *)getIv:(int)length {
    NSData* ivData = [self makeRandData:length];
    
    if(!ivData) {
        return @"";
    }
    
    NSString* iv = [self dataToHexString:ivData];
    return iv;
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidEndEditing:(UITextField *)textField {
    if (textField == self.TFsiteCode) {
        if (textField.text.length > 0) {
            NSString *siteCode = [self.TFsiteCode.text substringWithRange:NSMakeRange(self.TFsiteCode.text.length-3, 3)];
            self.TFotpAlias.text = [NSString stringWithFormat:@"512%@000000001", siteCode];
        }
    }
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField {
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - keyboard actions
- (void)handleKeyboardWillShowNote:(NSNotification *)notification
{
    [self.view addGestureRecognizer:bgTap];
}

- (void)handleKeyboardWillHideNote:(NSNotification *)notification
{
    [self.view removeGestureRecognizer:bgTap];
}

#pragma mark - Buton Actions
- (IBAction)actionBtnSetDeviceId:(id)sender {
    // Sync
   NSDictionary *resDic = [MobileAuth setDeviceId:[[UIDevice currentDevice] identifierForVendor].UUIDString];
   
   NSString *title = @"Set Device ID";
   NSString *msg = [self jsonStringPrint:resDic];
   [self showResult:title message:msg];
}

- (IBAction)actionBtnVersion:(id)sender {
    // Sync
    NSDictionary *responseDic = [MobileAuth getVersion];
    
    NSString *title = @"버전 조회";
    NSString *msg = [self jsonStringPrint:responseDic];
    [self showResult:title message:msg];
}

- (IBAction)actionBtnInfo:(id)sender {
    NSString *title = @"정보 조회";
    __block NSString *msg = nil;
    
    // Sync
    NSDictionary *responseDic = [MobileOTP getAllInfo];
    msg = [self jsonStringPrint:responseDic];
    [self showResult:title message:msg];
    
    
    // Async
//    [MobileOTP getInfo:^(BOOL success, NSDictionary *result) {
//        msg = [self jsonStringPrint:result];
//        [self showResult:title message:msg];
//    }];
}

- (IBAction)actionBtnIssue:(id)sender {
    
    NSString *title = @"OTP 발급";
    __block NSString *msg = nil;
    
    if (self.TFotpAlias.text && self.TFotpAlias.text.length != 0) {
        NSData *otpKey1 = [self hexToByteArray:@"000000000000000000000000000000002F5B8B5ED829A8CEF1599FFF8D87C17B"];
        NSData *otpKey2 = [self hexToByteArray:@"000000000000000000000000000000001798277C4DDB8D2A733F2E7AB65CDF63"];
        
        // Sync
        NSDictionary *responseDic = [MobileOTP issue:self.TFotpAlias.text otpKey1:otpKey1 otpKey2:otpKey2];
        msg = [self jsonStringPrint:responseDic];
        [self showResult:title message:msg];
        
        
        // Async
    //    [MobileOTP issue:self.TFotpAlias.text otpKey1:otpKey1 otpKey2:otpKey2 callback:^(BOOL success, NSDictionary *result) {
    //        msg = [self jsonStringPrint:result];
    //        [self showResult:title message:msg];
    //    }];
    } else {
        [self showResult:@"OTP 발급 실패" message:@"otpAlias를 입력해주세요."];
    }
}

- (IBAction)actionBtnGenerate:(id)sender {
    NSString *title = @"OTP 생성";
    __block NSString *msg = nil;
    
    if (self.TFotpAlias.text && self.TFotpAlias.text.length != 0) {
        NSData *otpTime = [self hexToByteArray:@"FE45EC819CEE7C07967A656CC6A16B2C"];
        NSData *hti = [self hexToByteArray:@"2CF24DBA5FB0A30E26E83B2AC5B9E29E1B161E5C1FA7425E73043362938B9824"];
        
        // Sync
        NSDictionary *responseDic = [MobileOTP generate:self.TFotpAlias.text siteCode:self.TFsiteCode.text otpTime:otpTime hti:hti isEncrypt:NO];
        msg = [self jsonStringPrint:responseDic];
        [self showResult:title message:msg];
        
        
        // Async
    //    [MobileOTP generate:sNum siteCode:self.TFsiteCode.text otpTime:otpTime hti:hti isEncrypt:YES callback:^(BOOL success, NSDictionary *result){
    //        msg = [self jsonStringPrint:responseDic];
    //        [self showResult:title message:msg];
    //    }];
    } else {
        [self showResult:@"OTP 생성 실패" message:@"otpAlias를 입력해주세요."];
    }
    
}

- (IBAction)actionBtnDisuse:(id)sender {
    NSString *title = @"OTP 폐기";
    __block NSString *msg = nil;
    
    if (self.TFotpAlias.text && self.TFotpAlias.text.length != 0) {
        
        // Sync
        NSDictionary *responseDic = [MobileOTP disuse:self.TFotpAlias.text];
        msg = [self jsonStringPrint:responseDic];
        [self showResult:title message:msg];
        
        
        // Async
    //    [MobileOTP disuse:sNum callback:^(BOOL success, NSDictionary *result) {
    //        msg = [self jsonStringPrint:responseDic];
    //        [self showResult:title message:msg];
    //    }];
    } else {
        [self showResult:@"OTP 폐기 실패" message:@"otpAlias를 입력해주세요."];
    }
}

#pragma mark - Encrypt/Decrypt
- (IBAction)actionEncryptBtn:(id)sender {
    NSString *title = @"암호화";
   __block NSString *msg = @"";
    
    [self.TFencrypt setText:@""];
    [self.TFdecrypt setText:@""];
    
    NSString *segmentOTPKey = [NSString stringWithFormat:@"%ld", (long)self.segmentOTPKey.selectedSegmentIndex];
    
    NSMutableData *data = [NSMutableData dataWithData:[ENCRYPTION_DATA dataUsingEncoding:NSUTF8StringEncoding]];
    
    int64_t lStart = [[NSDate date] timeIntervalSince1970] * 1000.0;
    
    // Sync
    NSMutableDictionary *resDic = [NSMutableDictionary dictionaryWithDictionary:[MobileOTP encrypt:self.TFotpAlias.text otpKeyIndex:segmentOTPKey data:data]];

    if ([[resDic objectForKey:@"resultCode"] isEqualToString:RESULT_CODE_SUCCESS]) {
        
        int64_t lEnd = [[NSDate date] timeIntervalSince1970] * 1000.0;
        lEnd = lEnd - lStart;
        NSLog(@"YJ << encrypt time : %lld", lEnd);
        
        NSData *encData = [resDic objectForKey:@"encData"];
        NSString *strEnc = [self dataToHexString:encData];
        [resDic setObject:strEnc forKey:@"encData"];

        NSLog(@"====TFencrypt %@", self.TFencrypt.text);
        [self.TFencrypt setText:strEnc];

        msg = [self jsonStringPrint:resDic];
        [self showResult:title message:msg];
    } else {
        msg = [self jsonStringPrint:resDic];
        [self showResult:@"암호화 실패" message:msg];
    }
    
    [data resetBytesInRange:NSMakeRange(0, data.length)];
    
    
    
//    // Async
//    [MobileOTP encrypt:@"512010000000001" otpKeyIndex:segmentOTPKey data:data callback:^(BOOL success, NSDictionary *result) {
//        if (success) {
//            NSData *encData = [result objectForKey:@"encData"];
//            NSString *strEnc = [self dataToHexString:encData];
//
//            NSMutableDictionary *resDic = [NSMutableDictionary dictionaryWithDictionary:result];
//            [resDic setObject:strEnc forKey:@"encData"];
//
//            [self.TFencrypt setText:strEnc];
//
//            msg = [self jsonStringPrint:resDic];
//            [self showResult:title message:msg];
//
//        } else {
//            msg = [self jsonStringPrint:result];
//            [self showResult:@"암호화 실패" message:msg];
//        }
//    }];
}

- (IBAction)actionDecryptBtn:(id)sender {
    NSString *title = @"복호화";
    __block NSString *msg = @"";
    
    NSString *segmentOTPKey = [NSString stringWithFormat:@"%ld", (long)self.segmentOTPKey.selectedSegmentIndex];
    
    NSMutableData *data = [NSMutableData dataWithData:[self dataFromHexString:self.TFencrypt.text]];
                
    // Sync
    NSMutableDictionary *resDic = [MobileOTP decrypt:self.TFotpAlias.text otpKeyIndex:segmentOTPKey data:data];
    
    if (resDic != nil && [[resDic objectForKey:@"resultCode"] isEqualToString:RESULT_CODE_SUCCESS]) {
        
        NSMutableData *decData = [resDic objectForKey:@"decData"];
        NSMutableString *strDec = [[NSMutableString alloc] initWithData:decData encoding:NSUTF8StringEncoding];
        [resDic setObject:strDec forKey:@"decData"];
        
        NSLog(@"----TFdecrypt %@", strDec);
        [self.TFdecrypt setText:strDec];
        [self.TFencrypt setText:@""];

        msg = [self jsonStringPrint:resDic];
        [self showResult:title message:msg];
        
        [strDec replaceCharactersInRange:NSMakeRange(0, strDec.length) withString:@"0"];
        [decData resetBytesInRange:NSMakeRange(0, decData.length)];
        
    } else {
        msg = [self jsonStringPrint:resDic];
        [self showResult:@"복호화 실패" message:msg];
    }
    
    [data resetBytesInRange:NSMakeRange(0, data.length)];
    [resDic removeAllObjects];

    
//    // Async
//    [MobileOTP decrypt:@"512010000000001" otpKeyIndex:segmentOTPKey data:data callback:^(BOOL success, NSDictionary *result) {
//        if (success) {
//            NSData *decData = [result objectForKey:@"decData"];
//            NSString *strDec = [[NSString alloc] initWithData:decData encoding:NSUTF8StringEncoding];
//
//            NSMutableDictionary *resDic = [NSMutableDictionary dictionaryWithDictionary:result];
//            [resDic setObject:strDec forKey:@"decData"];
//
//            [self.TFdecrypt setText:strDec];
//            [self.TFencrypt setText:@""];
//
//            msg = [self jsonStringPrint:resDic];
//            [self showResult:title message:msg];
//
//        } else {
//            msg = [self jsonStringPrint:result];
//            [self showResult:@"복호화 실패" message:msg];
//        }
//    }];
}


// encrypt : aes with iv
-(IBAction)actionEncrypAEStBtn:(id)sender {
    NSString *title = @"암호화(AES)";
    __block NSString *msg = @"";
     
    [self.TFencrypt setText:@""];
    [self.TFdecrypt setText:@""];
     
    NSString *segmentOTPKey = [NSString stringWithFormat:@"%ld", (long)self.segmentOTPKey.selectedSegmentIndex];
    NSMutableData *data = [NSMutableData dataWithData:[ENCRYPTION_DATA dataUsingEncoding:NSUTF8StringEncoding]];
    NSData *iv = [self dataFromHexString:ivHexStr];
    
     // Sync
    NSMutableDictionary *resDic = [NSMutableDictionary dictionaryWithDictionary:[MobileOTP encrypt:self.TFotpAlias.text otpKeyIndex:segmentOTPKey iv: iv data:data]];

     if ([[resDic objectForKey:@"resultCode"] isEqualToString:RESULT_CODE_SUCCESS]) {

         NSData *encData = [resDic objectForKey:@"encData"];
         NSString *strEnc = [self dataToHexString:encData];
         [resDic setObject:strEnc forKey:@"encData"];

         [self.TFencrypt setText:strEnc];

         msg = [self jsonStringPrint:resDic];
         [self showResult:title message:msg];
     } else {
         msg = [self jsonStringPrint:resDic];
         [self showResult:@"암호화 실패" message:msg];
     }
    
    
    
//    // Async
//    [MobileOTP encrypt:self.TFotpAlias.text otpKeyIndex:segmentOTPKey iv: iv data:data callback:^(BOOL success, NSDictionary *result) {
//        if (success) {
//            NSData *encData = [result objectForKey:@"encData"];
//            NSString *strEnc = [self dataToHexString:encData];
//
//            NSMutableDictionary *resDic = [NSMutableDictionary dictionaryWithDictionary:result];
//            [resDic setObject:strEnc forKey:@"encData"];
//
//            [self.TFencrypt setText:strEnc];
//
//            msg = [self jsonStringPrint:resDic];
//            [self showResult:title message:msg];
//
//        } else {
//            msg = [self jsonStringPrint:result];
//            [self showResult:@"암호화 실패" message:msg];
//        }
//    }];
    
    [data resetBytesInRange:NSMakeRange(0, data.length)];
}


// decrypt : aes with iv
- (IBAction)actionDecryptAESBtn:(id)sender {
    NSString *title = @"복호화(AES)";
    __block NSString *msg = @"";
    
    NSString *segmentOTPKey = [NSString stringWithFormat:@"%ld", (long)self.segmentOTPKey.selectedSegmentIndex];
    NSMutableData *data = [NSMutableData dataWithData:[self dataFromHexString:self.TFencrypt.text]];
    NSData *iv = [self dataFromHexString:ivHexStr];
                
    // Sync
    NSMutableDictionary *resDic = [MobileOTP decrypt:self.TFotpAlias.text otpKeyIndex:segmentOTPKey iv:iv data:data];
    
    if (resDic != nil && [[resDic objectForKey:@"resultCode"] isEqualToString:RESULT_CODE_SUCCESS]) {
        
        NSMutableData *decData = [resDic objectForKey:@"decData"];
        NSMutableString *strDec = [[NSMutableString alloc] initWithData:decData encoding:NSUTF8StringEncoding];
        [resDic setObject:strDec forKey:@"decData"];
        
        NSLog(@"----TFdecrypt %@", strDec);
        [self.TFdecrypt setText:strDec];
        [self.TFencrypt setText:@""];

        msg = [self jsonStringPrint:resDic];
        [self showResult:title message:msg];
        
        [strDec replaceCharactersInRange:NSMakeRange(0, strDec.length) withString:@"0"];
        [decData resetBytesInRange:NSMakeRange(0, decData.length)];
        
    } else {
        msg = [self jsonStringPrint:resDic];
        [self showResult:@"복호화 실패" message:msg];
    }
    
    [data resetBytesInRange:NSMakeRange(0, data.length)];
    [resDic removeAllObjects];

    
//    // Async
//    [MobileOTP decrypt:@"512010000000001" otpKeyIndex:segmentOTPKey data:data callback:^(BOOL success, NSDictionary *result) {
//        if (success) {
//            NSData *decData = [result objectForKey:@"decData"];
//            NSString *strDec = [[NSString alloc] initWithData:decData encoding:NSUTF8StringEncoding];
//
//            NSMutableDictionary *resDic = [NSMutableDictionary dictionaryWithDictionary:result];
//            [resDic setObject:strDec forKey:@"decData"];
//
//            [self.TFdecrypt setText:strDec];
//            [self.TFencrypt setText:@""];
//
//            msg = [self jsonStringPrint:resDic];
//            [self showResult:title message:msg];
//
//        } else {
//            msg = [self jsonStringPrint:result];
//            [self showResult:@"복호화 실패" message:msg];
//        }
//    }];
}


@end
