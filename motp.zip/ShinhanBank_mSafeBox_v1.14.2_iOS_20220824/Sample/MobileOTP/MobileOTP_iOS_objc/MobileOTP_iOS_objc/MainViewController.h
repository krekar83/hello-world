//
//  MainViewController.h
//  MobileOTP_iOS_objc
//
//  Created by 강은경 on 2021/03/17.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MainViewController : UIViewController
- (IBAction)actionBtnAuth:(id)sender;
- (IBAction)actionBtnOTP:(id)sender;

@end

NS_ASSUME_NONNULL_END
